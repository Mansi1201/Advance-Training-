package com.Mansi.training;

public abstract class Instrument {
	public abstract void play();
}
